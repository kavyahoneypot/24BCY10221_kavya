package com.knowledgevault;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import static com.mongodb.client.model.Filters.eq;

public class ResourceManager {

    private MongoCollection<Document> collection;

    public ResourceManager(MongoDatabase database) {
        collection = database.getCollection("resources");
    }

    // ADD RESOURCE
    public void addResource(Resource resource) {

        Document document = new Document("title", resource.getTitle())
                .append("subject", resource.getSubject())
                .append("category", resource.getCategory())
                .append("description", resource.getDescription());

        collection.insertOne(document);

        System.out.println("Resource Added Successfully!");
    }

    // VIEW ALL RESOURCES
    public void viewResources() {

        for (Document document : collection.find()) {

            System.out.println("--------------------");
            System.out.println("Title: " + document.getString("title"));
            System.out.println("Subject: " + document.getString("subject"));
            System.out.println("Category: " + document.getString("category"));
            System.out.println("Description: " + document.getString("description"));
        }
    }

    // SEARCH RESOURCE
    public void searchResource(String title) {

        Document document = collection.find(eq("title", title)).first();

        if (document != null) {

            System.out.println("--------------------");
            System.out.println("Title: " + document.getString("title"));
            System.out.println("Subject: " + document.getString("subject"));
            System.out.println("Category: " + document.getString("category"));
            System.out.println("Description: " + document.getString("description"));

        } else {

            System.out.println("Resource not found!");
        }
    }

    // DELETE RESOURCE
    public void deleteResource(String title) {

        Document document = collection.find(eq("title", title)).first();

        if (document != null) {

            collection.deleteOne(eq("title", title));

            System.out.println("Resource deleted successfully!");

        } else {

            System.out.println("Resource not found!");
        }
    }
}