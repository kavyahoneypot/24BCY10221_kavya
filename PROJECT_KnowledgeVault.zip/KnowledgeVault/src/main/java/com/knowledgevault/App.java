package com.knowledgevault;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

import java.util.Scanner;

public class App {

    public static void main(String[] args) {

        MongoClient client = MongoClients.create("mongodb://localhost:27017");

        MongoDatabase database = client.getDatabase("knowledgevault");

        ResourceManager manager = new ResourceManager(database);

        Scanner sc = new Scanner(System.in);

        int choice;

        do {

            System.out.println("\n===== KNOWLEDGEVAULT =====");
            System.out.println("1. Add Resource");
            System.out.println("2. View Resources");
            System.out.println("3. Search Resource");
            System.out.println("4. Delete Resource");
            System.out.println("5. Exit");

            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

                case 1:

                    System.out.print("Enter Title: ");
                    String title = sc.nextLine();

                    System.out.print("Enter Subject: ");
                    String subject = sc.nextLine();

                    System.out.print("Enter Category: ");
                    String category = sc.nextLine();

                    System.out.print("Enter Description: ");
                    String description = sc.nextLine();

                    Resource resource = new Resource(
                            title,
                            subject,
                            category,
                            description
                    );

                    manager.addResource(resource);
                    break;

                case 2:

                    manager.viewResources();
                    break;

                case 3:

                    System.out.print("Enter Title to Search: ");
                    String searchTitle = sc.nextLine();

                    manager.searchResource(searchTitle);
                    break;

                case 4:

                    System.out.print("Enter Title to Delete: ");
                    String deleteTitle = sc.nextLine();

                    manager.deleteResource(deleteTitle);
                    break;

                case 5:

                    System.out.println("Exiting KnowledgeVault...");
                    break;

                default:

                    System.out.println("Invalid Choice!");
            }

        } while (choice != 5);

        client.close();
        sc.close();
    }
}