package com.knowledgevault;

public class Resource {

    private String title;
    private String subject;
    private String category;
    private String description;

    public Resource(String title, String subject, String category, String description) {
        this.title = title;
        this.subject = subject;
        this.category = category;
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public String getSubject() {
        return subject;
    }

    public String getCategory() {
        return category;
    }

    public String getDescription() {
        return description;
    }
}